shasha-chatbot/
├── app.py
├── bot_logic.py
├── requirements.txt
├── templates/
│   └── index.html
└── static/
    └── script.js
